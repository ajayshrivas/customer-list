Stick Notes
Stick Notes developed in Node-Js and Sequelize with HTML5 Form validation with AJAX JavaScript and Jquery.

What Do You need for use??

1. User has installation of Node-Js 

2. install npm module
      -> npm install
      
3. User must create database and update /config/db.js file with database details.

4. User can change hostname and port from app.js file.

5. For use this Stick Notes, User have to register first.

6. For forgot-password, we use SMTP and user must update /config/settings.json file with SMTP details.
 