const db = {
    data : { 
        host : 'localhost',
        username : 'stickyboard',
        password : 'Lu$xt640',
        database : 'admin_stickyboard'
    }
}

module.exports = db
