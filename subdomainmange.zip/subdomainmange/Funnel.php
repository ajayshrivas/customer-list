<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Funnel extends CI_Controller {

    private $folder;
		
	function __construct() {
		parent::__construct();
		if(!( $this->session->userdata( 'loginstatus' ) && ($this->session->userdata( 'type' ) === '2'))){
			redirect(base_url());
        }
        $this->load->helper('jwt_helper');
        // $this->folder = $this->session->userdata( 'type' );
        $this->folder = 'home';
	}
	
	public function index(){
		echo 'All is well';
    }
	
    public function checkAuthentication(){

        if(isset($_COOKIE['mhAccessToken'])){
            $jwt = $_COOKIE['mhAccessToken'];
            $r = jwtDecode( $jwt, MHSECRETKEY );
            return $r;		
        }
		return false;
	}
	private function checkUserLoginStatus(){
		if(!isset($this->session->userdata['loginstatus']) || $this->session->userdata['type'] != 2 )
			redirect(base_url());
	}
    public function createFunnel(){

        $this->checkUserLoginStatus();
        // if($this->checkAuthentication()){
            $acceptURL = array( base_url() . $this->folder . '/funnels' );
          
            if(in_array( $_SERVER['HTTP_REFERER'], $acceptURL ) && isset($_POST['funnelFormSubmit']) && $_POST['funnelFormSubmit']){
                if(!empty($_POST['funnel_name'])){
               	  $check_domain = 'plrfunnels.in';
                  $subdomain = 'pf'.random_generator(0, 6);
                  
                  $this->load->Library('Manage_cpanel_domain',['domain' => C_MAINDOMAIN, 'cPanelUserName' => CPANEL_USERNAME, 'cPanelPassword' => CPANEL_PASSWORD, 'mainDomainIP' => C_MAINDOMAINIP]);
                    
                     $domainData = [
                            "subDomainName" =>$subdomain,
                            "dir" => "public_html/customers",
                        ];
				    $res = $this->manage_cpanel_domain->addSubDomain($domainData);
                    if($res['status']==1){
                        $res = '{"result":{"id":"'.$subdomain.'.'.$check_domain.'","type":"CNAME","name":"'.$subdomain.'.'.$check_domain.'","content":"plrfunnels.in","proxiable":true,"proxied":true,"ttl":1,"locked":false,"zone_id":"434675157b2ad059af862d04f4b73d77","zone_name":"plrfunnels.in","modified_on":"2020-03-09T13:19:10.654606Z","created_on":"2020-03-09T13:19:10.654606Z","meta":{"auto_added":false,"managed_by_apps":false,"managed_by_argo_tunnel":false}},"success":true,"errors":'.$res['message'].',"messages":'.$res['message'].'}';
                    }else{
                        $res = 0;
                    }
                    // print_r($addDomain);
                    // die;
                    // $res = json_encode( putCloudflareSubDomain( $subdomain ) );
                    $wl = getDomainDesign();
                   
                    if(!empty($wl)){
                        $sddomain = $this->DBfile->get_data( TBL_USER_SETTINGS, array( 'user_id' => $wl['parentID'], 'key' => 'whiteLabelDomainSettings' ) );
						if(!empty($sddomain)){
							$doma = json_decode($sddomain[0]['value'], true);
                            $site_name = $doma['domain'];
                        }else{
                            $site_name = '';
                        }
                    }else{
                        $site_name = 'pf';
                    }
                   
                    $customize = '{"logo":{"url":"https:\/\/https://plrfunnels.in/\/assets\/images\/c_logo.png","file_id":"0"},"favicon":{"url":"https:\/\/https://plrfunnels.in/\/assets\/images\/c_fav.png","file_id":"0"},"backgroundColor":"#3c06f2","loginBoxBackground":"#ffffff","loginTextColor":"#9ca2ab","headingColor":"#a77bff","forgetPasswordColor":"#a77bff","buttonBackgroundColor":"#a77bff","buttonTextColor":"#ffffff","headingText":"Welcome Back!","subHeadingText":"Please Login To Your Account To Continue","emailPlaceholder":"Email Address","passwordPlaceholder":"Password","rememberText":"Keep Me Signed In","forgetPasswordText":"Forgot Password?","buttonText":"Login Now","dontAccountText":"Don\u2019t Have An Account?","registerNow":"Register Now","allDataLoop":"1","copyrightText":"Copyright \u00a9 2021 '.$site_name.'. All Rights Reserved","disableBackgroundImage":"false","background":{"url":"https:\/\/https://plrfunnels.in/\/assets\/images\/c_bg.jpg","file_id":"0"},"registerLinkColor":"#a77bff","registerHeadingText":"Welcome Back!","registerSubHeadingText":"Please register for new account","fullName":"Full Name","registerEmailPlaceholder":"Email Address","registerPasswordPlaceholder":"Password","registerButtonText":"Signup Now","haveAccountText":"Have An Account?","loginNow":"Login Now","forgetHeadingText":"Forgot Your Password?","forgetSubHeadingText":"Enter Your Registered Email Address Below","forgetEmailPlaceholder":"Email Address","forgetButtonText":"Request for otp","forgetRememberPassword":"Remember The Password?","forgetloginNow":"Login Now"}';
                    
                    $userID = $this->session->userdata('id');
                    $insertData = array(
                        'user_id' => $userID,
                        'funnel_name' => $_POST['funnel_name'],
                        'sub_domain' => $subdomain,
                        'cloudflare_subdomain_return' => $res,
                        'customize' => $customize,
                        'funnel_type' => 'paid',
                        'isCreated' => date('Y-m-d H:i:s'),
                        'isUpdated' => date('Y-m-d H:i:s'),
                        'status' => 1
                    );
					
                    $f_id = $this->DBfile->put_data(TBL_FUNNELS,$insertData);
                     
                    $insertFEData = array(
                        'welcometxt' => '{"from_name":"'.$site_name.'","subject":"Welcome!","content":"<div><span style=\"font-weight: bold;\">Hi {member_name},<\/span><\/div><div><br><\/div><div>Congratulations! and thank you for being a part of <span style=\"font-weight: bold;\">'.$site_name.'<\/span>.<\/div><div><br><\/div><div>Please whitelist our email by adding this to your address book. This makes sure you get all your important updates and you can contact the support team easily.<br><\/div><div><br><\/div><div><span style=\"font-weight: bold;\">Your Login Details -<\/span><br><\/div><div>Please keep these login details safe as they are your keys to the software and your member area:<br><\/div><div><br><\/div><div><span style=\"font-weight: bold;\">Members Area - {login_url}<br><\/span><\/div><div><div><span style=\"font-weight: bold;\">Email - {member_email}<\/span><\/div><div><span style=\"font-weight: bold;\">Password - {member_password}<\/span><\/div><\/div><div><span style=\"font-weight: bold;\"><br><\/span><\/div><div><div style=\"\">Please, don\'t reply to this email as it is automated.<br><\/div><div style=\"\">If you face any issue please get back to us on support@'.strtolower($site_name).'.app<\/div><div style=\"\"><br><\/div><div style=\"\">To Your Success,<\/div><div style=\"\"><span style=\"font-weight: bold;\">The&nbsp;<span style=\"letter-spacing: 0.4px;\">'.$site_name.'<\/span>&nbsp;Team<\/span><\/div><\/div>"}',
                        'resettxt' => '{"from_name":"'.$site_name.'","subject":"Reset Password Link","content":"<span style=\"font-weight: bold;\">Hi {member_name},<\/span><div><span style=\"font-weight: bold;\"><br><\/span><\/div><div>{OTP}&nbsp; is your One-Time Password for changing the password by you on '.$site_name.'. This OTP is valid for 30 minutes.<br><\/div><div><br><\/div><div>If you did not attempt the forgotten password that triggered this One Time Password please ignore this mail.<br><\/div><div><span style=\"font-weight: bold;\"><br><\/span><\/div><div><div style=\"letter-spacing: 0.4px;\">To Your Success,<\/div><div style=\"letter-spacing: 0.4px;\"><span style=\"font-weight: bold;\">The&nbsp;<span style=\"letter-spacing: 0.4px;\">'.$site_name.'<\/span>&nbsp;Team<\/span><\/div><\/div><div style=\"letter-spacing: 0.4px;\"><br><\/div><div style=\"\">* This is an auto-generated email. Please do not reply to this email.<br><\/div>"}',
                        'expiretxt' => '{"from_name":"'.$site_name.'","subject":"Your access expiring soon","content":"<span style=\"font-weight: 700; letter-spacing: 0.4px;\">Hi {member_name},<\/span><div><span style=\"font-weight: 700; letter-spacing: 0.4px;\"><br><\/span><\/div><div>Your access to <span style=\"font-weight: bold;\">{<\/span><span style=\"font-family: &quot;Red Hat Display&quot;, sans-serif; font-weight: 700; letter-spacing: 0.4px; background-color: rgb(245, 247, 251);\">funnel_title<\/span><span style=\"font-weight: bold;\">}<\/span> - <span style=\"font-weight: bold;\">{payment_gateway_title}<\/span> is going to expire soon.<br><\/div><div>To prolong your access, please click the link below.<br><\/div><div><span style=\"font-weight: bold;\">{buy_url}<\/span><br><\/div><div><span style=\"font-weight: bold;\"><br><\/span><\/div><div>To Your Online Success,<br><\/div><div><span style=\"font-weight: bold;\">{<\/span><span style=\"font-family: &quot;Red Hat Display&quot;, sans-serif; font-weight: 700; letter-spacing: 0.4px; background-color: rgb(245, 247, 251);\">funnel_title<\/span><span style=\"font-weight: bold;\">}<\/span><br><\/div><div><span style=\"font-weight: bold;\"><br><\/span><\/div><div><div style=\"letter-spacing: 0.4px;\">To Your Success,<\/div><div style=\"letter-spacing: 0.4px;\"><span style=\"font-weight: bold;\">The&nbsp;<span style=\"letter-spacing: 0.4px;\">'.$site_name.'<\/span>&nbsp;Team<\/span><\/div><\/div>"}',
                        'send_type' => !empty($wl) ? 'mandrill' : 'plrfunnels-smtp',
                        'user_id' => $userID,
                        'f_id' => $f_id
                    );
                    $this->DBfile->put_data( TBL_FUNNEL_EMAILS, $insertFEData );
                   

                    redirect( $this->folder . "/funnel/{$f_id}", 'refresh' );
                }else{
                    //echo '3';die();
                    redirect( $this->folder . '/funnel', 'refresh' );
                }
            }else{
                //echo '2';die();
               	redirect(base_url());
            }
        // }else{
        //     //echo '1';die();
        //     	redirect(base_url());
        // }

    }

    public function deleteFunnel(){
        $this->checkUserLoginStatus();
        $f_id = $_POST['funnelID'];
        $userID = $this->session->userdata( 'id' );
        $where = array( 'f_id' => $f_id, 'user_id' => $userID );
        $result = $this->DBfile->get_data( TBL_FUNNELS, $where, 'cloudflare_subdomain_return as cloudflare, is_delete' );
       
        if(!empty($result) && $result[0]['is_delete']){
            $r = json_decode( $result[0]['cloudflare'], true );

            $identiFire = '';
            if(!empty($r) && isset($r['result']['id'])){
                $identiFire = $r['result']['id'];
            }
           
            if($identiFire != ''){
                $res = deleteCloudflareSubDomain( $identiFire );
            }

            // $members = $this->DBfile->get_data( TBL_MEMBERS, array( 'parent_user_id' => $userID, 'f_id' => $f_id ), 'm_id' );
            // if(!empty($members)){
            //     $members = array_column($members, 'm_id');
            //     $sql = "DELETE FROM " . TBL_MEMBER_DRIP . " WHERE member_id IN(" . join($members, ',') . ")";
            //     $this->DBfile->query( $sql, false );
                
            //     $sql = "DELETE FROM " . TBL_MEMBER_DRIP_CONTENT . " WHERE member_id IN(" . join($members, ',') . ")";
            //     $this->DBfile->query( $sql, false );
            // }

            // $this->DBfile->delete_data( TBL_FUNNEL_EMAILS, $where );
            // $this->DBfile->delete_data( TBL_BUILDER_PAGE, $where );
            // $this->DBfile->delete_data( TBL_FUNNEL_PAYMENT, $where );
            // $this->DBfile->delete_data( TBL_MEMBER_RECORDS, $where );
            $this->DBfile->delete_data( TBL_EDITOR_TEMPLATES, $where );
            // $this->DBfile->delete_data( TBL_MEMBERS, array( 'parent_user_id' => $userID, 'f_id' => $f_id ) );
            $this->DBfile->delete_data( TBL_FUNNELS, $where );
            echo json_encode( array( 'status' => 1, 'msg' => 'Funnel deleted successfully.', 'url' => base_url($this->folder . '/funnels') ) );
        }
        die();
    }
    public function deletecover(){
        $this->checkUserLoginStatus();
        $f_id = $_POST['funnelID'];
        $userID = $this->session->userdata( 'id' );
        $where = array( 'f_id' => $f_id, 'user_id' => $userID );
        $result = $this->DBfile->get_data( TBL_COVER_PAGE, $where, 'is_delete' );
       
        if(!empty($result) && $result[0]['is_delete']){
            $r = json_decode( $result[0]['cloudflare'], true );

            $identiFire = '';
            if(!empty($r) && isset($r['result']['id'])){
                $identiFire = $r['result']['id'];
            }
           
            $this->DBfile->delete_data( TBL_COVER_PAGE, $where );
            echo json_encode( array( 'status' => 1, 'msg' => 'Cover Page deleted successfully.', 'url' => base_url($this->folder . '/cover_design') ) );
        }
        die();
    }
    public function cloneFunnel(){
        if($this->checkAuthentication()){
            //$headers = getallheaders();
			//if(isset($headers['Origin']) && $headers['Origin'] == ALLOWORIGIN){
                $f_id = $_POST['funnelID'];
                $userID = $this->session->userdata( 'user_id' );
                $where = array( 'f_id' => $f_id, 'user_id' => $userID );
                $result = $this->DBfile->get_data( TBL_FUNNELS, $where, '*' );

                if(!empty($result)){
                    $subdomain = 'ez' . random_generator(0, 6);
                    $res = json_encode( putCloudflareSubDomain( $subdomain ) );
                    $insertData = $result[0];
                    unset($insertData['f_id']);
                    $insertData['funnel_name'] = $insertData['funnel_name'] . ' - Copy';
                    $insertData['sub_domain'] = $subdomain;
                    $insertData['cloudflare_subdomain_return'] = $res;
                    $f_id = $this->DBfile->put_data( TBL_FUNNELS, $insertData );

                    $emails = $this->DBfile->get_data( TBL_FUNNEL_EMAILS, $where );
                    $pages = $this->DBfile->get_data( TBL_BUILDER_PAGE, $where );
                    $payments = $this->DBfile->get_data( TBL_FUNNEL_PAYMENT, $where );

                    if(!empty($emails)){
                        $insertDataEmails = $emails[0];
                        unset($insertDataEmails['fe_id']);
                        $this->DBfile->put_data( TBL_FUNNEL_EMAILS, $insertDataEmails );
                    }
                    if(!empty($payments)){
                        $insertDataPayments = $payments[0];
                        unset($insertDataPayments['fp_id']);
                        $this->DBfile->put_data( TBL_FUNNEL_PAYMENT, $insertDataPayments );
                    }
                    if(!empty($pages)){
                        $insertDataPages = $pages[0];
                        unset($insertDataPages['id']);
                        $this->DBfile->put_data( TBL_BUILDER_PAGE, $insertDataPages );
                    } 

                }

                echo json_encode( array( 'status' => 1, 'msg' => 'Funnel copied successfully.', 'url' => base_url($this->folder . '/funnels') ) );
            //}else{
                //echo json_encode( array( 'status' => 0, 'msg' => 'Something may be wrong.' ) );
            //}
        }else{
            echo json_encode( array( 'status' => 0, 'msg' => 'Please, Login again.' ) );
        }
        die();
    }

    public function saveFunnelDomain(){
        if($this->checkAuthentication()){
            $funnelID = $_POST['funnelID'];
            $acceptURL = array( base_url() . $this->folder . '/funnel/' . $funnelID . '/domain' );
            
            if(in_array( $_SERVER['HTTP_REFERER'], $acceptURL )){

                $f_id = $_POST['funnelID'];
                $subdomaintot = $this->DBfile->get_data( TBL_FUNNELS, array('sub_domain'=>$_POST['sub_domain_name'],'f_id !=' => $f_id), 'count(sub_domain) as total' );
                if(!$subdomaintot[0]['total']){
                    if(!empty($_POST['sub_domain_name'])){
                        $userID = $this->session->userdata( 'user_id' );
                        $where = array( 'f_id' => $f_id, 'user_id' => $userID );
                        $result = $this->DBfile->get_data( TBL_FUNNELS, $where, 'cloudflare_subdomain_return as cloudflare, custom_domain, sub_domain' );
    
                        if(!empty($result)){

                            $r = json_decode( $result[0]['cloudflare'], true );
            
                            $identiFire = '';
                            if(!empty($r) && isset($r['result']['id'])){
                                $identiFire = $r['result']['id'];
                            }
                            if($identiFire != ''){


                                if(!empty($result[0]['custom_domain']) && !empty($result[0]['sub_domain'])){
                                    $ol = removeDomain($result[0]['custom_domain'], $result[0]['sub_domain']);
                                }
                                if(!empty(($_POST['domain_name']) && !empty($_POST['sub_domain_name']))){
                                    //deleteCloudflareSubDomain($identiFire);
                                    $r = createDomain($_POST['domain_name'], $_POST['sub_domain_name']);
                                    if(!$r['status']){
                                        echo json_encode( array( 'status' => 0, 'msg' => $r['msg']) );
                                        die();
                                    }
                                    $res = '{"result":{"id":"'.$_POST['sub_domain_name'].'.plrfunnels.in","type":"CNAME","name":"'.$_POST['sub_domain_name'].'.plrfunnels.in","content":"plrfunnels.in","proxiable":true,"proxied":true,"ttl":1,"locked":false,"zone_id":"434675157b2ad059af862d04f4b73d77","zone_name":"plrfunnels.in","modified_on":"2020-03-09T13:19:10.654606Z","created_on":"2020-03-09T13:19:10.654606Z","meta":{"auto_added":false,"managed_by_apps":false,"managed_by_argo_tunnel":false}},"success":true,"errors":[],"messages":[]}';
                                    $res = json_decode( $res, true );
                                }else{
                                    //$res = updateCloudflareSubDomain( $identiFire, $_POST['sub_domain_name'] );
                                    $res = putCloudflareSubDomain( $_POST['sub_domain_name'] );
                                }
	

                                $arr = array();
                                if($res['success']){
                                    $arr = array(
                                        'sub_domain' => $_POST['sub_domain_name'],
                                        'cloudflare_subdomain_return' => json_encode( $res ),
                                        'custom_domain' => $_POST['domain_name']
                                    );
                                }
                                $arr['funnel_type'] = $_POST['domain_access'];
                                $this->DBfile->set_data( TBL_FUNNELS, $arr, $where );
                            }else{

                                if(!empty($result[0]['custom_domain']) && !empty($result[0]['sub_domain'])){
                                    $ol = removeDomain($result[0]['custom_domain'], $result[0]['sub_domain']);
                                }
                                if(!empty(($_POST['domain_name']) && !empty($_POST['sub_domain_name']))){
                                    $r = createDomain($_POST['domain_name'], $_POST['sub_domain_name']);
                                    if(!$r['status']){
                                        echo json_encode( array( 'status' => 0, 'msg' => $r['msg']) );
                                        die();
                                    }
                                    $res = '{"result":{"id":"'.$_POST['sub_domain_name'].'.plrfunnels.in","type":"CNAME","name":"'.$_POST['sub_domain_name'].'.plrfunnels.in","content":"plrfunnels.in","proxiable":true,"proxied":true,"ttl":1,"locked":false,"zone_id":"434675157b2ad059af862d04f4b73d77","zone_name":"plrfunnels.in","modified_on":"2020-03-09T13:19:10.654606Z","created_on":"2020-03-09T13:19:10.654606Z","meta":{"auto_added":false,"managed_by_apps":false,"managed_by_argo_tunnel":false}},"success":true,"errors":[],"messages":[]}';
                                    $res = json_decode( $res, true );
                                }else{
                                    $res = putCloudflareSubDomain( $_POST['sub_domain_name'] );
                                }

                                if($res['success']){
                                    $arr = array(
                                        'sub_domain' => $_POST['sub_domain_name'],
                                        'custom_domain' => $_POST['domain_name'],
                                        'cloudflare_subdomain_return' => json_encode( $res ),
                                        'funnel_type' => $_POST['domain_access']
                                    );
                                    $this->DBfile->set_data( TBL_FUNNELS, $arr, $where );
                                }else{
                                    echo json_encode( array( 'status' => 0, 'msg' => $res['errors'][0]['message'] ) );
                                    die();            
                                }
                            }
                            echo json_encode( array( 'status' => 1, 'msg' => 'SubDomain settings are updated successfully.', 'url' => base_url($this->folder."/funnel/{$f_id}/domain"), 'identiFire' => $identiFire != '' ? $identiFire : '' ) );
                        } 
                    }else{
                        echo json_encode( array( 'status' => 0, 'msg' => 'SubDomain name is required.' ) );
                    } 
                }else{
                    echo json_encode( array( 'status' => 0, 'msg' => 'This subdomain name is already used by another account.' ) );
                }
            }else{
                echo json_encode( array( 'status' => 0, 'msg' => 'Something may be wrong.' ) );
            }
        }else{
            echo json_encode( array( 'status' => 0, 'msg' => 'Please, Login again.' ) );
        }
		die();
    }
    
    public function saveProduct(){
        if($this->checkAuthentication()){
            //$headers = getallheaders();
			//if(isset($headers['Origin']) && $headers['Origin'] == ALLOWORIGIN){
                if(empty($_POST['mhProductID'])){
                    echo json_encode( array( 'status' => 0, 'msg' => 'Please, select atleast one product.' ) );
                    die();
                }
                $userID = $this->session->userdata( 'user_id' );
                $f_id = $_POST['funnelID'];
                $where = array( 'f_id' => $f_id, 'user_id' => $userID );
                $result = $this->DBfile->get_data( TBL_FUNNELS, $where, 'products' );
                $products = array();
                $bool = true;
                if(!empty($result)){
                    $products = json_decode( $result[0]['products'], true );
                    if(!empty($products)){
                        for($i=0;$i<count($products);$i++){
                            if(in_array( $products[$i]['p_id'], $_POST['mhProductID'] )){
                                $key = array_search($products[$i]['p_id'], $_POST['mhProductID']);
                                unset($_POST['mhProductID'][$key]);
                            } 
                        }
                    }                    
                    $newProd = array_values( $_POST['mhProductID'] );
                }
                if($bool){
                    $data = array();
                    for($r=0;$r<count($newProd);$r++){
                        $data[] = array(
                            'p_id' => $newProd[$r],
                            'bonus' => $_POST['mhProductBonus'],
                            'salesPageURL' => $_POST['mhSalesPageUrl']
                        );
                    }
                    if(!empty($products)) $products = array_merge($data, $products); else $products = $data;
                    $what['products'] = json_encode( $products );
                    $this->DBfile->set_data( TBL_FUNNELS, $what, $where );

                    echo json_encode( array( 'status' => 1, 'msg' => 'Product added successfully.', 'url' => base_url( $this->folder . "/funnel/{$f_id}/fprod" ) ) );
                }else{
                    echo json_encode( array( 'status' => 0, 'msg' => 'Product already added.' ) );
                }
                die();
            //}
        }
    }

    public function deleteProductFromFunnel(){
        if($this->checkAuthentication()){
            //$headers = getallheaders();
			//if(isset($headers['Origin']) && $headers['Origin'] == ALLOWORIGIN){
                $userID = $this->session->userdata( 'user_id' );
                $f_id = $_POST['funnelID'];
                $where = array( 'f_id' => $f_id, 'user_id' => $userID );
                $result = $this->DBfile->get_data( TBL_FUNNELS, $where, 'products' );
                $products = array();
                $bool = true;
                if(!empty($result)){
                    $products = json_decode( $result[0]['products'], true );
                    for($i=0;$i<count($products);$i++){
                        if($products[$i]['p_id'] == $_POST['id']){
                            unset($products[$i]);
                            break;
                        }
                    }
                }
                $what['products'] = json_encode( array_values( $products ) );
                $this->DBfile->set_data( TBL_FUNNELS, $what, $where );
                echo json_encode( array( 'status' => 1, 'msg' => 'Product deleted successfully.', 'url' => base_url( $this->folder . "/funnel/{$f_id}/fprod" ) ) );
                die();
            //}
        }
    }

    private function deleteImageFile( $imageID ){
        $userID = $this->session->userdata( 'user_id' );
        $media = $this->DBfile->get_data( TBL_MEDIA, array( 'm_id' => $imageID, 'user_id' => $userID ), 'thumb,file' );

        if(!empty($media)){
            $rootpath = $_SERVER['DOCUMENT_ROOT'];
            $thumb = str_replace(base_url(), $rootpath, $media[0]['thumb']);
            $file = str_replace(base_url(), $rootpath, $media[0]['file']);
            unlink( $file );
            if(!empty($thumb)) unlink( $thumb );
            $this->DBfile->delete_data( TBL_MEDIA, array( 'm_id' => $imageID, 'user_id' => $userID ) );
        }
    }

    public function saveCustomizeOptions(){
        if($this->checkAuthentication()){
            //$headers = getallheaders();
			//if(isset($headers['Origin']) && $headers['Origin'] == ALLOWORIGIN){
                $userID = $this->session->userdata( 'user_id' );
                $f_id = $_POST['funnelID'];
                $where = array( 'f_id' => $f_id, 'user_id' => $userID );
                $result = $this->DBfile->get_data( TBL_FUNNELS, $where, 'customize' );
                unset( $_POST['funnelID'] );
                if(!empty($result)){
                    $customize = json_decode( $result[0]['customize'], true );
                    if(isset($_POST['logoImage'])){
                        if(isset($customize['logo']['file_id']) && $_POST['logoImageID'] != $customize['logo']['file_id']){
                            $this->deleteImageFile( $customize['logo']['file_id'] );
                        }
                        $customize['logo'] = array(
                            'url' => $_POST['logoImage'],
                            'file_id' => $_POST['logoImageID']
                        );
                    }
                    if(isset($_POST['faviconImage'])){
                        if(isset($customize['favicon']['file_id']) && $_POST['faviconImageID'] != $customize['favicon']['file_id']){
                            $this->deleteImageFile( $customize['favicon']['file_id'] );
                        }
                        $customize['favicon'] = array(
                            'url' => $_POST['faviconImage'],
                            'file_id' => $_POST['faviconImageID']
                        );
                    }
                    if(isset($_POST['backgroundImage'])){
                        if(isset($customize['background']['file_id']) && $_POST['backgroundImageID'] != $customize['background']['file_id']){
                            $this->deleteImageFile( $customize['background']['file_id'] );
                        }
                        $customize['background'] = array(
                            'url' => $_POST['backgroundImage'],
                            'file_id' => $_POST['backgroundImageID']
                        );
                    }
                    if(isset($_POST['allDataLoop'])){
                        unset( $_POST['allDataLoop'] );
                        foreach( $_POST as $pk=>$pv ){
                            $customize[$pk] = $pv;
                        }
                    }
                    if(isset($_POST['disableBackgroundImage'])){
                        $customize['disableBackgroundImage'] = $_POST['disableBackgroundImage'];
                    }
                    $what['customize'] = json_encode( $customize );
                    $this->DBfile->set_data( TBL_FUNNELS, $what, $where );
                }

                echo json_encode( array( 'status' => 1, 'msg' => 'Settings saved successfully.' ) );
                die();
            //}
        }
    }

    public function saveAutoresponder(){
        if($this->checkAuthentication()){
            //$headers = getallheaders();
			//if(isset($headers['Origin']) && $headers['Origin'] == ALLOWORIGIN){
                $userID = $this->session->userdata( 'user_id' );
                $f_id = $_POST['funnelID'];
                $where = array( 'f_id' => $f_id, 'user_id' => $userID );
                $result = $this->DBfile->get_data( TBL_FUNNELS, $where, 'autoresponder' );
                $a__ = array();

                $value = explode( '-!!-=-!!-', $_POST['listID'] );
                $listName = $value[0];
                $listID = $value[1];
                if(!empty($result) && !empty($result[0]['autoresponder'])){
                    $bool = true;
                    $a__ = json_decode( $result[0]['autoresponder'], true );
                    for($i=0;$i<count($a__);$i++){
                        if($a__[$i]['responder'] == $_POST['responder'] && $a__[$i]['listID'] == $listID){
                            $bool = false;
                        }
                    }
                    if(!$bool){
                        echo json_encode( array( 'status' => 0, 'msg' => 'This List is already added.' ) );
                        die();
                    }
                }
                $a__[] = array(
                    'id' => getRnadomNumber(),
                    'responder' => $_POST['responder'],
                    'listName' => $listName,
                    'listID' => $listID
                );
                $what['autoresponder'] = json_encode( $a__ );
                $this->DBfile->set_data( TBL_FUNNELS, $what, $where );
                echo json_encode( array( 'status' => 1, 'msg' => 'Autoresponder service added successfully.', 'url' => base_url($this->folder . "/funnel/{$f_id}/fautoresponder") ) );
                die();
            //}
        } 
    }

    public function deleteAutoresponder(){
        if($this->checkAuthentication()){
            //$headers = getallheaders();
			//if(isset($headers['Origin']) && $headers['Origin'] == ALLOWORIGIN){
                $userID = $this->session->userdata( 'user_id' );
                $f_id = $_POST['funnelID'];
                $where = array( 'f_id' => $f_id, 'user_id' => $userID );
                $result = $this->DBfile->get_data( TBL_FUNNELS, $where, 'autoresponder' );
                $a__ = array();
                if(!empty($result)){
                    $bool = true;
                    $a__ = json_decode( $result[0]['autoresponder'], true );
                    for($i=0;$i<count($a__);$i++){
                        if($a__[$i]['id'] == $_POST['id']){
                            $key = $i;
                            $bool = false;
                            break;
                        }
                    }
                    if($bool){
                        echo json_encode( array( 'status' => 0, 'msg' => 'This List is not available.' ) );
                        die();
                    }
                    unset($a__[$key]);
                    $what['autoresponder'] = json_encode( array_values( $a__ ) );
                    $this->DBfile->set_data( TBL_FUNNELS, $what, $where );
                    echo json_encode( array( 'status' => 1, 'msg' => 'Autoresponder service deleted successfully.', 'url' => base_url($this->folder . "/funnel/{$f_id}/fautoresponder") ) );
                    die(); 
                }
            //}
        } 
    }

    public function addMember(){
        if($this->checkAuthentication()){
            //$headers = getallheaders();
			//if(isset($headers['Origin']) && $headers['Origin'] == ALLOWORIGIN){
                $userID = $this->session->userdata( 'user_id' );
                $f_id = $_POST['funnelID'];

                $fmember = $this->DBfile->get_data( TBL_MEMBERS, array( 'f_id' => $f_id, 'email' => $_POST['mhMemberEmail'] ) );

                if(!empty($fmember) && empty($_POST['member_id'])){
                    echo json_encode( array( 'status' => 0, 'msg' => 'Email already exists.' ) );
                    die();
                }

                if(empty($_POST['products'])){
                    echo json_encode( array('status' => 0, 'msg' => 'Atleast one product is required.') );
                    die();
                }

                $where = array( 'user_id' => $userID, 'f_id' => $f_id );
                $result = $this->DBfile->get_data( TBL_FUNNELS, $where, 'sub_domain,custom_domain,autoresponder,social_proof' );

                $date = date('Y-m-d H:i:s');
                $mdata = array(
                    'payment_date' => $date,
                    'source' => 'admin',
                    'f_id' => $_POST['funnelID'],
                    'parent_user_id' => $userID,
                    'name' => $_POST['mhMemberFullName'],
                    'email' => $_POST['mhMemberEmail'],
                    'password' => md5($_POST['mhMemberPassword']),
                    'product_list' => isset($_POST['products']) ? json_encode( $_POST['products'] ) : '',
                    'expire_type' => $_POST['expire_type'],
                    'expire_time' => $_POST['expire_number'],
                    'expire_notice_period' => $_POST['notify_period'],
                    'isCreated' => $date,
                    'isUpdated' => $date,
                    'status' => $_POST['mhMemberStatus']
                );

                $mhSendMailCheckbox = $_POST['mhSendMailCheckbox'];

                if($_POST['mhSendMailCheckbox']){
                    if(!empty($result[0]['custom_domain'])){
                        $loginUrl = 'https://'.$result[0]['custom_domain'];
                    }else{
                        $loginUrl = 'https://'.$result[0]['sub_domain'].'.plrfunnels.in/';
                    }
                    $returnData = welcomeMailSend($userID, $f_id, $loginUrl, array(
                        'name' => $_POST['mhMemberFullName'],
                        'email' => $_POST['mhMemberEmail'],
                        'password' => $_POST['mhMemberPassword']
                    ) );
                }
                
                if($_POST['mhAddResponderCheckbox']){

                    if(!empty($result)){

                        addListInAutoresponder( $userID, array(
                            'name' => $_POST['mhMemberFullName'],
                            'email' => $_POST['mhMemberEmail'],
                            'autoresponder' => $result[0]['autoresponder']
                        ) );

                    }

                }

                if(!empty($_POST['member_id'])){
                    if(empty($_POST['mhMemberPassword'])){
                        unset($mdata['password']);
                    }
                    unset($mdata['isCreated']);
                    unset($mdata['source']);
                    $this->DBfile->set_data( TBL_MEMBERS, $mdata, array( 'm_id' => $_POST['member_id'] ) );
                    $m_id = $_POST['member_id'];
                    echo json_encode( array( 'status' => 1, 'msg' => 'Member is updated successfully.', 'url' => base_url( $this->folder . "/funnel/{$f_id}/members" ) ) );
                }else{
                    $m_id = $this->DBfile->put_data( TBL_MEMBERS, $mdata );
                    if(!isset($_POST['bulk_member']))
                        echo json_encode( array( 'status' => 1, 'msg' => 'Member is added successfully.', 'url' => base_url( $this->folder . "/funnel/{$f_id}/members" ) ) );
                }

                if(!empty($mdata['product_list'])){
                    $product_list = json_decode( $mdata['product_list'], true );
                    if(!is_array($product_list)) $product_list = array( $product_list );
                    for($i=0;$i<count($product_list);$i++){
                        $product = $this->DBfile->get_data( TBL_PRODUCTS, array('p_id'=>$product_list[$i]), 'emailcontent,webhook,name' );
                        $productDrip = $this->DBfile->get_data( TBL_PRODUCT_DRIP, array('p_id'=>$product_list[$i]), 'media_id,days_interval' );
                        $productDripMember = $this->DBfile->get_data( TBL_MEMBER_DRIP, array('product_id'=>$product_list[$i],'member_id'=>$m_id), '*' );
                        $productDripContent = $this->DBfile->get_data( TBL_PRODUCT_DRIP_CONTENT, array('p_id'=>$product_list[$i]), 'pdc_id, days_interval' );
                        $productDripContentMember = $this->DBfile->get_data( TBL_MEMBER_DRIP_CONTENT, array('product_id'=>$product_list[$i],'member_id'=>$m_id), '*' );
                        if(!empty($result[0]['social_proof'])){
                            sendDataToWebHook( $result[0]['social_proof'], array(
                                'product_name' => $product[0]['name'],
                                'member_name' => $mdata['name']
                            ) );
                        }
                        if(!empty($product) && empty($productDripContentMember)){
                            $ci = 0;
                            for($j=0;$j<count($productDripContent);$j++){
                                $days_interval = $productDripContent[$j]['days_interval'];
                                $ci = $ci + $days_interval;
                                $date = date('Y-m-d', strtotime("+{$ci} day"));
                                $dripFeed = array(
                                    'member_id' => $m_id,
                                    'product_id' => $product_list[$i],
                                    'pdc_id' => $productDripContent[$j]['pdc_id'],
                                    'date' => $date,
                                    'status' => 1
                                );
                                $this->DBfile->put_data( TBL_MEMBER_DRIP_CONTENT, $dripFeed );
                            }  
                        }
                        if(!empty($product) && empty($productDripMember)){
                            sendDataToWebHook( $product[0]['webhook'], $_REQUEST );
                            if($mhSendMailCheckbox){
                                sendProductMail(
                                    $returnData,
                                    $product[0]['emailcontent'],
                                    $_POST['mhMemberFullName']
                                );
                            }
                            $ci = 0;
                            for($j=0;$j<count($productDrip);$j++){
                                $days_interval = $productDrip[$j]['days_interval'];
                                $ci = $ci + $days_interval;
                                $date = date('Y-m-d', strtotime("+{$ci} day"));
                                $dripFeed = array(
                                    'member_id' => $m_id,
                                    'product_id' => $product_list[$i],
                                    'media_id' => $productDrip[$j]['media_id'],
                                    'date' => $date,
                                    'status' => 1
                                );
                                $this->DBfile->put_data( TBL_MEMBER_DRIP, $dripFeed );
                            }        
                        }
                    }
                }

                if(!isset($_POST['bulk_member'])) die();                

            //}
        }
    }

    public function deleteMember(){
        if($this->checkAuthentication()){
            //$headers = getallheaders();
			//if(isset($headers['Origin']) && $headers['Origin'] == ALLOWORIGIN){
                $userID = $this->session->userdata( 'user_id' );
                $m_id = $_POST['member_id'];
                $this->DBfile->delete_data( TBL_MEMBER_DRIP, array( 'member_id' => $m_id ) );
                $this->DBfile->delete_data( TBL_MEMBER_DRIP_CONTENT, array( 'member_id' => $m_id ) );
                $this->DBfile->delete_data( TBL_MEMBERS, array( 'm_id' => $m_id ) );
                $this->DBfile->delete_data( TBL_MEMBER_RECORDS, array( 'm_id' => $m_id ) );
                echo json_encode( array( 'status' => 1, 'msg' => 'Member is deleted successfully.' ) );
                die();
            //}
        }
    }

    public function saveSetting(){
        if($this->checkAuthentication()){
            //$headers = getallheaders();
			//if(isset($headers['Origin']) && $headers['Origin'] == ALLOWORIGIN){
                $userID = $this->session->userdata( 'user_id' );
                $f_id = $_POST['funnelID'];
                $where = array( 'f_id' => $f_id, 'user_id' => $userID );
                $what = array();
                if(isset($_POST['mhFunnelName'])){
                    $what['funnel_name'] = $_POST['mhFunnelName'];
                    $what['tagline'] = $_POST['mhFunnelTagline'];

                    $this->DBfile->set_data( TBL_FUNNELS, $what, $where );

                    echo json_encode( array( 'status' => 1, 'msg' => 'Funnel details are saved successfully.' ) );
                    die();
                }

                if(isset($_POST['formdata']) && $_POST['formdata'] == 'welcome'){
                    $formdata = array(
                        'from_name' => $_POST['mhWelcomeName'],
                        'subject' => $_POST['mhWelcomeMsg'],
                        'content' => $_POST['welcomeEmailEditor']
                    );
                    $what['welcometxt'] = json_encode( $formdata );
                }

                if(isset($_POST['formdata']) && $_POST['formdata'] == 'reset'){
                    $formdata = array(
                        'from_name' => $_POST['mhResetName'],
                        'subject' => $_POST['mhResetMailSubject'],
                        'content' => $_POST['resetEmailEditor']
                    );
                    $what['resettxt'] = json_encode( $formdata );
                }

                if(isset($_POST['formdata']) && $_POST['formdata'] == 'expire'){
                    $formdata = array(
                        'from_name' => $_POST['mhExpiringName'],
                        'subject' => $_POST['mhExpiringMailSubject'],
                        'content' => $_POST['expiringEmailEditor']
                    );
                    $what['expiretxt'] = json_encode( $formdata );
                }

                if(isset($_POST['formdata']) && $_POST['formdata'] == 'email'){
                    $what['send_type'] = $_POST['MailSentType'];
                    $what['mandrile_api'] = $_POST['mandrillExpiringApiKey'];
                    $what['mandrile_fromemail'] = $_POST['mandrillFromEmail'];
                    if(!empty($_POST['selectExpiringConfiguredAccount'])) $what['ea_id'] = $_POST['selectExpiringConfiguredAccount'];
                }

                $what['datetime'] = date('Y-m-d H:i:s');
                $what['status'] = 1;
                $what['user_id'] = $userID;
                $what['f_id'] = $f_id;
                
                $res = $this->DBfile->get_data( TBL_FUNNEL_EMAILS, $where );

                if(empty($res)){
                    $this->DBfile->put_data( TBL_FUNNEL_EMAILS, $what );
                }else{
                    $this->DBfile->set_data( TBL_FUNNEL_EMAILS, $what, $where );
                }

                echo json_encode( array( 'status' => 1, 'msg' => 'Funnel Email settings are saved successfully.' ) );

                die();
            //}
        }
    }

    public function exportMembers( $f_id ){
        $userID = $this->session->userdata( 'user_id' );
        $where = array(
            'parent_user_id' => $userID,
            'f_id' => $f_id
        );
        $members = $this->DBfile->get_data( TBL_MEMBERS, $where, 'name, email, source, isCreated' );

        if(empty($members)){
            redirect( $this->folder . '/funnel/'.$f_id.'/members', 'refresh' );
            die();
        }

        $funnel = $this->DBfile->get_data( TBL_FUNNELS, array('f_id'=>$f_id), 'funnel_name' );

        header("Content-type: application/csv");
        header("Content-Disposition: attachment; filename=\"{$funnel[0]['funnel_name']}".".csv\"");
        header("Pragma: no-cache");
        header("Expires: 0");

        $handle = fopen('php://output', 'w');

        fputcsv($handle, array(
            'name', 'email', 'source', 'join date'
        ));

        foreach ($members as $data) {
            fputcsv($handle, array(
                $data['name'],
                $data['email'],
                $data['source'],
                $data['isCreated']
            ));
        }
        fclose($handle);
        exit;
    }

    public function addPaymentGateway(){
        if($this->checkAuthentication()){
            //$headers = getallheaders();
			//if(isset($headers['Origin']) && $headers['Origin'] == ALLOWORIGIN){
                $userID = $this->session->userdata( 'user_id' );
                $f_id = $_POST['funnelID'];

                if(empty($_POST['fp_id'])){
                    $where = array( 'f_id' => $f_id, 'user_id' => $userID, 'gateway_id' => $_POST['mhGatewayProductId'] );
                    $r = $this->DBfile->get_data( TBL_FUNNEL_PAYMENT, $where );
                    if(!empty($r)){
                        echo json_encode( array('status' => 0, 'msg' => 'Gateway Product ID should be unique.') );
                        die();
                    }
                }

                if(empty($_POST['gatewayproducts'])){
                    echo json_encode( array('status' => 0, 'msg' => 'Atleast one product is required.') );
                    die();
                }

                if(!is_array($_POST['gatewayproducts'])){
                    $_POST['gatewayproducts'] = array($_POST['gatewayproducts']);
                }

                $idata = array(
                    'f_id' => $f_id,
                    'user_id' => $userID,
                    'name' => $_POST['mhGatewayTitle'],
                    'gateway_type' => $_POST['mhGatewayOptions'],
                    'gateway_id' => $_POST['mhGatewayProductId'],
                    'products' => json_encode($_POST['gatewayproducts']),
                    'expire_type' => $_POST['expire_type'],
                    'expire_time' => $_POST['expire_number'],
                    'expire_notice_period' => $_POST['notify_period'],
                    'datetime' => date('Y-m-d H:i:s'),
                    'status' => 1
                );

                if(!empty($_POST['fp_id'])){
                    $this->DBfile->set_data( TBL_FUNNEL_PAYMENT, $idata, array( 'fp_id' => $_POST['fp_id'] ) );
                    echo json_encode( array( 'status' => 1, 'msg' => 'Payment Gateway Details is updated successfully.', 'url' => base_url( $this->folder . "/funnel/{$f_id}/paymentGateway" ) ) );
                }else{
                    $this->DBfile->put_data( TBL_FUNNEL_PAYMENT, $idata );
                    echo json_encode( array( 'status' => 1, 'msg' => 'Payment Gateway Details is added successfully.', 'url' => base_url( $this->folder . "/funnel/{$f_id}/paymentGateway" ) ) );
                }

                die();
            //}
        }
    }

    public function deletePaymentGateway(){
        if($this->checkAuthentication()){
            //$headers = getallheaders();
			//if(isset($headers['Origin']) && $headers['Origin'] == ALLOWORIGIN){
                $userID = $this->session->userdata( 'user_id' );
                $fp_id = $_POST['fp_id'];
                $where = array( 'fp_id' => $fp_id );
                $this->DBfile->delete_data( TBL_FUNNEL_PAYMENT, $where );
                echo json_encode( array( 'status' => 1, 'msg' => 'Payment Gateway Details is deleted successfully.' ) );
                die();
            //}
        }
    }

    public function setProdOrder(){
        if($this->checkAuthentication()){
            //$headers = getallheaders();
			//if(isset($headers['Origin']) && $headers['Origin'] == ALLOWORIGIN){
                $userID = $this->session->userdata( 'user_id' );
                $f_id = $_POST['funnelID'];
                $where = array( 'f_id' => $f_id, 'user_id' => $userID );
                $result = $this->DBfile->get_data( TBL_FUNNELS, $where, 'products' );
                $newproducts = array();
                $bool = true;
                if(!empty($result)){
                    $products = json_decode( $result[0]['products'], true );
                    for($i=0;$i<count($_POST['products_id']);$i++){
                        $key = array_search( $_POST['products_id'][$i], array_column($products, 'p_id') );
                        $newproducts[] = $products[$key];
                    }
                    $what['products'] = json_encode( $newproducts );
                    $this->DBfile->set_data( TBL_FUNNELS, $what, $where );
                    echo json_encode(array('status'=>1,'msg'=>''));
                }
            //}
        }
    }

    public function deleteFunnelPage()
    {
        $this->checkUserLoginStatus();
        $id = $_POST['id'];
        $where = array( 'et_id' => $id );
        $this->DBfile->delete_data( TBL_EDITOR_TEMPLATES, $where );
        echo json_encode( array( 'status' => 1, 'msg' => 'Page is deleted successfully.' ) );
        die();
       
    }
    public function deleteCoverPage()
   {
        $this->checkUserLoginStatus();
        $id = $_POST['id'];
       
        $where = array( 'et_id' => $id );
        $this->DBfile->delete_data( TBL_COVER_PAGE_EDITOR_TEMPLATES, $where );
        echo json_encode( array( 'status' => 1, 'msg' => 'Cover is deleted successfully.' ) );
        die();
       
    }
    public function setTemplate(){
        // print_r($_POST);
        // die;
        $this->checkUserLoginStatus();
           
        $id = $_POST['template_id'];
        $product_id = $_POST['Product_id'];
        $where = array('et_id' => $id);
        $result = $this->DBfile->get_data( TBL_EDITOR_TEMPLATES, $where, 'et_type,campaign_html,campaign_settings' );
        if($id==3){
            $what = array(
                'campaign_html' => $result[0]['campaign_html'],
                 'campaign_settings' => $result[0]['campaign_settings'],
                 'et_type' => $result[0]['et_type'],
            );
        }else{
            $what = array(
                'campaign_html' => $result[0]['campaign_html'],
                'campaign_settings' => $result[0]['campaign_settings'],
                'product_id' => $product_id,
                'et_type' => $result[0]['et_type'],
            );
                
        }
        // print_r($what);
        // die;
        $where = array('et_id'=> $_POST['set_template_id']);
        $this->DBfile->set_data( TBL_EDITOR_TEMPLATES, $what, $where );
        $url = base_url( 'home/editor/'.$_POST['set_template_id'] );
        echo json_encode( array( 'status' => 1, 'url' => $url, 'msg' => 'Page template has set successfully.' ) );
        die();
    }

    public function addFunnelPage(){
        $this->checkUserLoginStatus();
        $date = date('Y-m-d H:i:s');
        $userID = $this->session->userdata( 'id' );
        $templateId = 0;
        $page_title = trim($_POST['pageTitleInput']);
        $f_id = $_POST['funnelID'];

        $arr = array(
            'campaign_name' => $page_title,
            'et_type' => $_POST['pageTemplateType'],
            'f_id' => $f_id,
            'user_id' => $userID,
            'isCreated' => $date,
            'isUpdated' => $date,
            'status' => 1
        );
       
        $insert_id = $this->DBfile->put_data( TBL_EDITOR_TEMPLATES, $arr );
				
		$url = base_url(). 'home/choose-page-template/'.$insert_id;

        echo json_encode( array( 'status' => 1, 'url' => $url, 'msg' => 'Page is created successfully.' ) );
        die();
    }

    public function saveSocialProoof(){
		if($this->checkAuthentication()){
			//$headers = getallheaders();
            //if(isset($headers['Origin']) && $headers['Origin'] == ALLOWORIGIN){
                $userID = $this->session->userdata( 'user_id' );
                $f_id = $_POST['funnelID'];
                $where = array( 'user_id' => $userID, 'f_id' => $f_id );
                $arr = array(
                    'social_proof' => $_POST['webhook_url']
                );
                $this->DBfile->set_data( TBL_FUNNELS, $arr, $where );
                echo json_encode( array( 'status' => 1, 'msg' => 'Webhook URl has been saved.' ) );
            //}
			die();
		}
	}

    public function bulkUploadMember(){
        if($this->checkAuthentication()){
            //$headers = getallheaders();
            //if(isset($headers['Origin']) && $headers['Origin'] == ALLOWORIGIN){
                if(!empty($_POST['file'])){
                    $rootpath = $_SERVER['DOCUMENT_ROOT'];
                    $file = str_replace(base_url(), $rootpath, $_POST['file']['url']);
                    $file_data = fopen($file, "r");
                    $this->load->helper('email');
                    unset($_POST['mhMemberFile']);
                    $f_id = $_POST['funnelID'];
                    if(!empty($file_data)){
                        while (($emails = fgetcsv($file_data)) !== FALSE) {
                            if(valid_email( $emails[0] )){
                                $name = explode('@', $emails[0]);
                                $_POST['mhMemberFullName'] = $name[0];
                                $_POST['mhMemberEmail'] = $emails[0];
                                $_POST['bulk_member'] = 1;
                                $this->addMember();
                            }
                        }
                    }
                    fclose($file_data);
                    $this->deleteImageFile( $_POST['file']['file_id'] );
                    
                    echo json_encode( array( 'status' => 1, 'msg' => 'All members are uploaded.', 'url' => base_url( $this->folder . "/funnel/{$f_id}/members" ) ) );
                    
                }

            //}

        }
        die();
    }

   public function addDomain(){
        $this->checkUserLoginStatus();
        createDomain($_POST['domain_name'], $_POST['csub_domain_name']);
        echo json_encode( array('status' => 1) );
       
        die();
    }
    public function removeDomain(){
        if($this->checkAuthentication()){
            removeDomain($_POST['remove_domain_name'], $_POST['remove_sub_domain_name']);
            echo json_encode( array('status' => 1) );
        }
        die();
    }
    public function removeSubdomain(){
        $this->checkUserLoginStatus();
      
        $removeDomainName = $_POST['domain'].'.'.C_MAINDOMAIN;
      
        $this->load->Library('manage_cpanel_domain',['domain' => C_MAINDOMAIN, 'cPanelUserName' => CPANEL_USERNAME, 'cPanelPassword' => CPANEL_PASSWORD, 'mainDomainIP' => C_MAINDOMAINIP]);
     
        
        $removeDomin = $this->manage_cpanel_domain->removeSubDomain([
            "subDomainName" => $removeDomainName, 
        ]);
      
        if($removeDomin['status']==1){
            echo json_encode( array('status' => 1) );
        }else{
            echo json_encode( array('status' => 0) );
        }
        // deleteCloudflareSubDomain( $_POST['remove_sub_domain_name'].'.plrfunnels.in' );
        die();
    }
    public function addSubdomain(){
    //   die;
        $this->checkUserLoginStatus();

        $this->load->Library('Manage_cpanel_domain',['domain' => C_MAINDOMAIN, 'cPanelUserName' => CPANEL_USERNAME, 'cPanelPassword' => CPANEL_PASSWORD, 'mainDomainIP' => C_MAINDOMAINIP]);
       
        $domainData = [
            "subDomainName" =>!empty($_POST['sub_domain_name'])?$_POST['sub_domain_name']:'plr'.random_generator(),
            "dir" => "public_html/customers",
        ];
        
        $res = $this->manage_cpanel_domain->addSubDomain($domainData);
        
        if($res['status']==1){
            echo json_encode( array('status' => 1) );
        }else{
            echo json_encode( array('status' => 0) );
        }
        // putCloudflareSubDomain( $_POST['sub_domain_name'] );
        // echo json_encode( array('status' => 1) );
        die();
    }
    public function saveDomainSettings(){
        // die;
        $this->checkUserLoginStatus();
       
        $res = '{"result":{"id":"'.$_POST['sub_domain_name'].'.plrfunnels.in","type":"CNAME","name":"'.$_POST['sub_domain_name'].'.plrfunnels.in","content":"plrfunnels.in","proxiable":true,"proxied":true,"ttl":1,"locked":false,"zone_id":"434675157b2ad059af862d04f4b73d77","zone_name":"plrfunnels.in","modified_on":"2020-03-09T13:19:10.654606Z","created_on":"2020-03-09T13:19:10.654606Z","meta":{"auto_added":false,"managed_by_apps":false,"managed_by_argo_tunnel":false}},"success":true,"errors":[],"messages":[]}';
        $arr = array(
            'sub_domain' => $_POST['sub_domain_name'],
            'custom_domain' => $_POST['domain_name'],
            'cloudflare_subdomain_return' => json_encode( $res ),
            'funnel_type' => $_POST['domain_access']
        );
       
        $f_id = $_POST['funnelID'];
        $userID = $this->session->userdata( 'id' );
        $where = array( 'f_id' => $f_id, 'user_id' => $userID );
     
        $resp=$this->DBfile->set_data( TBL_FUNNELS, $arr, $where );
        $resp  = array( 'status' => 1, 'msg' => 'SubDomain settings are updated successfully.', 'url' => base_url($this->folder."/home/funnel/{$f_id}/domain"));
        // print_r($resp);
        // echo 1;
        echo json_encode($resp);
		die();
    }

    public function deleteSubDomain(){
        deleteCloudflareSubDomain( $_POST['identiFire'] );
        echo json_encode( array('status' => 1) );
    }
    
    
}
?>